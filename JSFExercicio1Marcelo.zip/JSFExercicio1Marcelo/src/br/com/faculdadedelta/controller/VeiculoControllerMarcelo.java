package br.com.faculdadedelta.controller;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import java.util.List;

import br.edu.faculdadedelta.dao.VeiculoDaoMarcelo;
import br.edu.faculdadedelta.modelo.VeiculoMarcelo;
@ManagedBean
@SessionScoped
public class VeiculoControllerMarcelo {
	private VeiculoMarcelo servico = new VeiculoMarcelo();
	private VeiculoDaoMarcelo dao = new VeiculoDaoMarcelo();
	
	public VeiculoMarcelo getVeiculoMarcelo() {
		return servico;
	}
	
	public void setVeiculoMarcelo(VeiculoMarcelo servico) {
		this.servico = servico;
	}
	
	
	public void limparCampos() {
		servico = new VeiculoMarcelo();
	}
	
	public String salvar() {
		try {
			if (servico.getId() == null) {
				// incluir
				dao.incluir(servico);
				FacesMessage mensagem = new FacesMessage("Inclus�o realizada com sucesso!");
				FacesContext.getCurrentInstance().addMessage(null, mensagem);
				limparCampos();
			} else {
				// alterar
				dao.alterar(servico);
				FacesMessage mensagem = new FacesMessage("Altera��o realizada com sucesso!");
				FacesContext.getCurrentInstance().addMessage(null, mensagem);
				limparCampos();
			}
		} catch (ClassNotFoundException | SQLException e) {
			FacesMessage mensagem = new FacesMessage("Erro ao realizar a opera��o. "
					+ "Tente novamente mais tarde. " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, mensagem);
			e.printStackTrace();
		}
		return "cadastroVenda.xhtml";
	}

	public List<VeiculoMarcelo> getLista() {
		List<VeiculoMarcelo> listaRetorno = new ArrayList<VeiculoMarcelo>();
		try {
			listaRetorno = dao.listar();
		} catch (ClassNotFoundException | SQLException e) {
			FacesMessage mensagem = new FacesMessage("Erro ao realizar a opera��o. "
					+ "Tente novamente mais tarde. " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, mensagem);
			e.printStackTrace();
		}
		return listaRetorno;
	}
	
	public String editar() {
		return "cadastroVenda.xhtml";
	}
	
	public String excluir() {
		try {
			dao.excluir(servico);
			FacesMessage mensagem = new FacesMessage("Exclus�o realizada com sucesso!");
			FacesContext.getCurrentInstance().addMessage(null, mensagem);
			limparCampos();
		} catch (ClassNotFoundException | SQLException e) {
			FacesMessage mensagem = new FacesMessage("Erro ao realizar a opera��o. "
					+ "Tente novamente mais tarde. " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, mensagem);
			e.printStackTrace();
		}
		return "listaVenda.xhtml";
	}
}

