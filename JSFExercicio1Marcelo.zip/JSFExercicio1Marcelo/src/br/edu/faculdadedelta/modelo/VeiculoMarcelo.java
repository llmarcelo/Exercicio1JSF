package br.edu.faculdadedelta.modelo;
import java.util.Date;
public class VeiculoMarcelo {
	private Long id;
	private String descCliente;
	private String descServico;
	private double valor;
	private double valorTotal;
	private int qtdeServico;
	private Date dataServico;
	public VeiculoMarcelo() {
	}
	public VeiculoMarcelo(Long id, String descCliente, String descServico, double valor, double valorTotal, int qtdeServico, Date dataServico) {
		this.id = id;
		this.descCliente = descCliente;
		this.descServico = descServico;
		this.valor = valor;
		this.setValorTotal(valorTotal);
		this.qtdeServico = qtdeServico;
		this.dataServico = dataServico;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescCliente() {
		return descCliente;
	}
	public void setDescCliente(String descCliente) {
		this.descCliente = descCliente;
	}
        public String getDescServico() {
		return descServico;
	}
	public void setDescServico(String descServico) {
		this.descServico = descServico;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		valorTotal = valor * qtdeServico;
		this.valorTotal = valorTotal;
	}
	public int getQtdeServico() {
		return qtdeServico;
	}
	public void setQtdeServico(int qtdeServico) {
		this.qtdeServico = qtdeServico;
	}
	public Date getDataServico() {
		return dataServico;
	}
	public void setDataServico(Date dataServico) {
		this.dataServico = dataServico;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VeiculoMarcelo other = (VeiculoMarcelo) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}