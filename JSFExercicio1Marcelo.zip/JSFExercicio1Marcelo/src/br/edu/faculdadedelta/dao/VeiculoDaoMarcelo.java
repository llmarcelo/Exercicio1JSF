package br.edu.faculdadedelta.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.edu.faculdadedelta.modelo.VeiculoMarcelo;
import br.edu.faculdadedelta.util.Conexao;
public class VeiculoDaoMarcelo {
	// C R U D
	
	public void incluir(VeiculoMarcelo servico) throws ClassNotFoundException, SQLException {
		Conexao conexao = new Conexao();
		Connection conn = conexao.conectarNoBanco();
		String sql = "INSERT INTO servicos (desc_cliente, desc_servico, qtde_servico, valor_unitario_servico, data_exec_servico) "
				+ " VALUES (?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, servico.getDescCliente().trim());
		ps.setString(2, servico.getDescServico().trim());
		ps.setInt(3, servico.getQtdeServico());
		ps.setDouble(4, servico.getValor());
		ps.setDate(5, new java.sql.Date(servico.getDataServico().getTime()));
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	
	public void alterar(VeiculoMarcelo servico) throws ClassNotFoundException, SQLException {
		Conexao conexao = new Conexao();
		Connection conn = conexao.conectarNoBanco();
		String sql = "UPDATE vendas SET desc_cliente = ?, "
				+ " desc_servico = ?, "
				+ " qtde_servico = ?, "
				+ " valor_unitario_servico = ?, "
				+ " data_exec_servico  = ? "
				+ " WHERE id_venda = ?";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, servico.getDescCliente().trim());
		ps.setString(2, servico.getDescServico().trim());
		ps.setInt(3, servico.getQtdeServico());
		ps.setDouble(4, servico.getValor());
		ps.setDate(5, new java.sql.Date(servico.getDataServico().getTime()));
		ps.setLong(6, servico.getId());
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	
	public void excluir(VeiculoMarcelo servico) throws ClassNotFoundException, SQLException {
		Conexao conexao = new Conexao();
		Connection conn = conexao.conectarNoBanco();
		String sql = "DELETE FROM servicos WHERE id_servico = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setLong(1, servico.getId());
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	
	public List<VeiculoMarcelo> listar() throws ClassNotFoundException, SQLException {
		Conexao conexao = new Conexao();
		Connection conn = conexao.conectarNoBanco();
		String sql = "SELECT id_servico, desc_cliente, desc_servico, qtde_servico, "
				+ " valor_unitario_servico, data_exec_servico FROM servicos";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<VeiculoMarcelo> listaRetorno = new ArrayList<VeiculoMarcelo>();
 		
		while (rs.next()) {
			VeiculoMarcelo servico = new VeiculoMarcelo();
			servico.setId(rs.getLong("id_servico"));
			servico.setDescCliente(rs.getString("desc_cliente").trim());
			servico.setDescServico(rs.getString("desc_servico").trim());
			servico.setQtdeServico(rs.getInt("qtde_servico"));
			servico.setValor(rs.getDouble("valor_unitario_servico"));
			servico.setDataServico(rs.getDate("data_exec_servico"));
			listaRetorno.add(servico);
		}
		rs.close();
		ps.close();
		conn.close();
		
		return listaRetorno;
	}
}
